package ru.lighthome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Light Home: лёгкий лаунчер для Яндекс ТВ (720p, ~1 ГБ RAM).
 * Только Android framework: без AndroidX, без блюра, без сети и фоновых сервисов.
 */
public class MainActivity extends Activity {

    // ================= Настройки (меняйте под себя) =================

    /** Плиток в ряду. */
    private static final int COLUMNS = 5;

    /**
     * Эти приложения идут первыми, в указанном порядке
     * (подстрока имени пакета или названия, регистр не важен).
     */
    private static final String[] FAVORITES = {
            "youtube", "kinopoisk", "кинопоиск", "okko", "ivi", "wink", "rutube",
            "twitch", "spotify", "vk", "netflix"
    };

    /** Пакеты, которые не показываем: сам лаунчер и штатный лаунчер Яндекса. */
    private static final String[] HIDDEN_PACKAGES = {
            "ru.lighthome", "com.yandex.tv.home"
    };

    /** true — без анимации фокуса (если ТВ тормозит). */
    private static final boolean REDUCED_MOTION = false;

    // ================= Состояние =================

    private static final String[] DAYS = {
            "", "ВОСКРЕСЕНЬЕ", "ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА"
    };
    private static final String[] MONTHS = {
            "ЯНВАРЯ", "ФЕВРАЛЯ", "МАРТА", "АПРЕЛЯ", "МАЯ", "ИЮНЯ",
            "ИЮЛЯ", "АВГУСТА", "СЕНТЯБРЯ", "ОКТЯБРЯ", "НОЯБРЯ", "ДЕКАБРЯ"
    };

    private int screenW, screenH;
    private float unit; // 1 единица = 1 px при высоте экрана 720

    private TextView greeting, clock, date;
    private TileGrid grid;
    private ScrollView scroll;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean reloadNeeded = true;
    private boolean loading = false;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateTime();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 60000 - (now % 60000) + 50);
        }
    };

    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            reloadNeeded = true;
            reloadAppsIfNeeded();
        }
    };

    private static class AppEntry {
        String pkg;
        String activity;
        String label;
        Drawable image;
        boolean isBanner;
        int rank;
    }

    // ================= Жизненный цикл =================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        unit = screenH / 720f;

        getWindow().setBackgroundDrawable(makeBackground());
        setContentView(buildUi());
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(packageReceiver, f);
    }

    @Override
    protected void onStop() {
        try {
            unregisterReceiver(packageReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(tick);
        tick.run();
        reloadAppsIfNeeded();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(tick);
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Нажатие Home: вернуться наверх и на первую плитку
        goToFirstTile();
    }

    @Override
    public void onBackPressed() {
        // Лаунчер не закрывается кнопкой «Назад»
        goToFirstTile();
    }

    private void goToFirstTile() {
        if (scroll != null) scroll.scrollTo(0, 0);
        if (grid != null && grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
    }

    // ================= UI =================

    private int px(float v) {
        return Math.round(v * unit);
    }

    private Drawable makeBackground() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF2C58CE, 0xFF173A9A, 0xFF08184C});
    }

    private TextView makeText(float sizePx, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx);
        t.setIncludeFontPadding(false);
        t.setSingleLine(true);
        if (medium) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setClipChildren(false);

        // ----- Левый верхний угол: приветствие, часы, дата -----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);

        greeting = makeText(13 * unit, 0xB3FFFFFF, true);
        greeting.setLetterSpacing(0.08f);
        header.addView(greeting);

        clock = makeText(56 * unit, Color.WHITE, true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = px(4);
        cp.bottomMargin = px(4);
        header.addView(clock, cp);

        date = makeText(13 * unit, 0xB3FFFFFF, true);
        date.setLetterSpacing(0.08f);
        header.addView(date);

        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.gravity = Gravity.TOP | Gravity.START;
        hp.leftMargin = Math.round(screenW * 0.055f);
        hp.topMargin = Math.round(screenH * 0.06f);
        root.addView(header, hp);

        // ----- Правый верхний угол: Источники, Wi-Fi, Настройки -----
        LinearLayout pills = new LinearLayout(this);
        pills.setOrientation(LinearLayout.HORIZONTAL);
        pills.setGravity(Gravity.CENTER_VERTICAL);

        TextView sources = makePill("Источники");
        sources.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSources();
            }
        });
        pills.addView(sources, pillParams(ViewGroup.LayoutParams.WRAP_CONTENT));

        IconView wifi = new IconView(this, IconView.WIFI);
        wifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHapp();
            }
        });
        // Долгое OK на иконке: обычные настройки сети
        wifi.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                openSettings(Settings.ACTION_WIFI_SETTINGS);
                return true;
            }
        });
        pills.addView(wifi, pillParams(px(44)));

        IconView gear = new IconView(this, IconView.GEAR);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings(Settings.ACTION_SETTINGS);
            }
        });
        pills.addView(gear, pillParams(px(44)));

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.gravity = Gravity.TOP | Gravity.END;
        pp.rightMargin = Math.round(screenW * 0.055f);
        pp.topMargin = Math.round(screenH * 0.075f);
        root.addView(pills, pp);

        // ----- Стеклянная панель с приложениями -----
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        scroll.setFocusable(false);

        GradientDrawable band = new GradientDrawable();
        band.setColor(0x2EFFFFFF);
        band.setCornerRadius(px(28));
        scroll.setBackground(band);
        scroll.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        scroll.setClipToOutline(true);

        grid = new TileGrid(this);
        scroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                bandWidth(), ViewGroup.LayoutParams.MATCH_PARENT);
        sp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        sp.topMargin = Math.round(screenH * 0.30f);
        sp.bottomMargin = Math.round(screenH * 0.06f);
        root.addView(scroll, sp);

        return root;
    }

    private int bandWidth() {
        return Math.round(screenW * 0.90f);
    }

    private LinearLayout.LayoutParams pillParams(int width) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, px(44));
        lp.leftMargin = px(12);
        return lp;
    }

    private Drawable pillBackground() {
        GradientDrawable focused = new GradientDrawable();
        focused.setColor(0xF2FFFFFF);
        focused.setCornerRadius(px(40));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(0x38FFFFFF);
        normal.setCornerRadius(px(40));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, focused);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    private TextView makePill(String text) {
        final TextView t = makeText(16 * unit, Color.WHITE, true);
        t.setText(text);
        t.setGravity(Gravity.CENTER);
        t.setPadding(px(22), 0, px(22), 0);
        t.setBackground(pillBackground());
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                t.setTextColor(hasFocus ? 0xFF0B1B4A : Color.WHITE);
            }
        });
        return t;
    }

    /** Иконки нарисованы кодом: не нужны картинки и шрифты. */
    private class IconView extends View {
        static final int WIFI = 0;
        static final int GEAR = 1;

        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();

        IconView(Context c, int type) {
            super(c);
            this.type = type;
            setBackground(pillBackground());
            setFocusable(true);
            setClickable(true);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onFocusChanged(boolean gainFocus, int direction, Rect previouslyFocusedRect) {
            super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            p.setColor(isFocused() ? 0xFF0B1B4A : Color.WHITE);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float s = Math.min(w, h);
            p.setStrokeWidth(Math.max(2f, s * 0.07f));

            if (type == WIFI) {
                float baseY = cy + s * 0.16f;
                float[] radii = {s * 0.12f, s * 0.22f, s * 0.32f};
                p.setStyle(Paint.Style.STROKE);
                for (float r : radii) {
                    oval.set(cx - r, baseY - r, cx + r, baseY + r);
                    canvas.drawArc(oval, 225, 90, false, p);
                }
                p.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, baseY, s * 0.04f, p);
            } else {
                p.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, s * 0.14f, p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI * 2 * i / 8;
                    float cos = (float) Math.cos(a);
                    float sin = (float) Math.sin(a);
                    canvas.drawLine(cx + cos * s * 0.22f, cy + sin * s * 0.22f,
                            cx + cos * s * 0.31f, cy + sin * s * 0.31f, p);
                }
                canvas.drawCircle(cx, cy, s * 0.24f, p);
            }
        }
    }

    /**
     * Своя сетка вместо GridLayout: не переставляет детей при фокусе
     * и рисует сфокусированную плитку поверх соседей.
     */
    private static class TileGrid extends ViewGroup {
        int cols = 1, tileW, tileH, gap, edge;

        TileGrid(Context c) {
            super(c);
            setClipChildren(false);
            setClipToPadding(false);
            setChildrenDrawingOrderEnabled(true);
        }

        void configure(int cols, int tileW, int tileH, int gap, int edge) {
            this.cols = cols;
            this.tileW = tileW;
            this.tileH = tileH;
            this.gap = gap;
            this.edge = edge;
        }

        private int gridWidth() {
            return cols * tileW + (cols - 1) * gap;
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            int n = getChildCount();
            int rows = (n + cols - 1) / cols;
            int childW = MeasureSpec.makeMeasureSpec(tileW, MeasureSpec.EXACTLY);
            int childH = MeasureSpec.makeMeasureSpec(tileH, MeasureSpec.EXACTLY);
            for (int i = 0; i < n; i++) getChildAt(i).measure(childW, childH);
            int h = rows == 0 ? 0 : rows * tileH + (rows - 1) * gap + 2 * edge;
            setMeasuredDimension(MeasureSpec.getSize(widthSpec), h);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int left0 = ((r - l) - gridWidth()) / 2;
            for (int i = 0; i < getChildCount(); i++) {
                int row = i / cols;
                int col = i % cols;
                int x = left0 + col * (tileW + gap);
                int y = edge + row * (tileH + gap);
                getChildAt(i).layout(x, y, x + tileW, y + tileH);
            }
        }

        @Override
        protected int getChildDrawingOrder(int count, int i) {
            int f = indexOfChild(getFocusedChild());
            if (f < 0 || f >= count) return i;
            if (i == count - 1) return f;
            if (i >= f) return i + 1;
            return i;
        }
    }

    // ================= Время и приветствие =================

    private void updateTime() {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        int m = c.get(Calendar.MINUTE);

        String hello;
        if (h < 5) hello = "ДОБРОЙ НОЧИ";
        else if (h < 12) hello = "ДОБРОЕ УТРО";
        else if (h < 18) hello = "ДОБРЫЙ ДЕНЬ";
        else hello = "ДОБРЫЙ ВЕЧЕР";

        greeting.setText(hello);
        clock.setText((h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m);
        date.setText(DAYS[c.get(Calendar.DAY_OF_WEEK)] + ", "
                + c.get(Calendar.DAY_OF_MONTH) + " " + MONTHS[c.get(Calendar.MONTH)]);
    }

    // ================= Список приложений =================

    private void reloadAppsIfNeeded() {
        if (!reloadNeeded || loading || grid == null) return;
        loading = true;
        reloadNeeded = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<AppEntry> apps = loadApps();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loading = false;
                        if (isDestroyed()) return;
                        populate(apps);
                        if (reloadNeeded) reloadAppsIfNeeded();
                    }
                });
            }
        }, "load-apps").start();
    }

    private List<AppEntry> loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<String>();
        List<ResolveInfo> all = new ArrayList<ResolveInfo>();

        Intent leanback = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        Intent normal = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> a = pm.queryIntentActivities(leanback, 0);
        List<ResolveInfo> b = pm.queryIntentActivities(normal, 0);
        if (a != null) all.addAll(a);
        if (b != null) all.addAll(b);

        List<AppEntry> out = new ArrayList<AppEntry>();
        for (ResolveInfo ri : all) {
            String pkg = ri.activityInfo.packageName;
            if (isHidden(pkg) || !seen.add(pkg)) continue;

            AppEntry e = new AppEntry();
            e.pkg = pkg;
            e.activity = ri.activityInfo.name;
            CharSequence lbl = ri.loadLabel(pm);
            e.label = lbl == null ? pkg : lbl.toString();

            Drawable banner = null;
            try {
                banner = ri.activityInfo.loadBanner(pm);
            } catch (Throwable ignored) {
            }
            if (banner != null) {
                e.image = banner;
                e.isBanner = true;
            } else {
                e.image = ri.loadIcon(pm);
                e.isBanner = false;
            }
            e.rank = rankOf(e);
            out.add(e);
        }

        Collections.sort(out, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry x, AppEntry y) {
                if (x.rank != y.rank) return x.rank < y.rank ? -1 : 1;
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        return out;
    }

    private boolean isHidden(String pkg) {
        for (String h : HIDDEN_PACKAGES) {
            if (h.equals(pkg)) return true;
        }
        return false;
    }

    private int rankOf(AppEntry e) {
        String pkg = e.pkg.toLowerCase(Locale.ROOT);
        String lbl = e.label.toLowerCase(Locale.ROOT);
        for (int i = 0; i < FAVORITES.length; i++) {
            if (pkg.contains(FAVORITES[i]) || lbl.contains(FAVORITES[i])) return i;
        }
        return 1000;
    }

    private void populate(List<AppEntry> apps) {
        int edge = px(20);
        int gap = px(14);
        int tileW = (bandWidth() - 2 * edge - (COLUMNS - 1) * gap) / COLUMNS;
        int tileH = tileW * 9 / 16;

        // Запоминаем, что было в фокусе, чтобы не прыгать при обновлении списка
        String focusedPkg = null;
        View cur = grid.getFocusedChild();
        if (cur != null && cur.getTag() instanceof AppEntry) {
            focusedPkg = ((AppEntry) cur.getTag()).pkg;
        }

        grid.removeAllViews();
        grid.configure(COLUMNS, tileW, tileH, gap, edge);

        View toFocus = null;
        for (AppEntry app : apps) {
            View tile = makeTile(app);
            grid.addView(tile);
            if (focusedPkg != null && focusedPkg.equals(app.pkg)) toFocus = tile;
        }

        if (toFocus == null && grid.getChildCount() > 0 && getCurrentFocus() == null) {
            toFocus = grid.getChildAt(0);
        }
        if (toFocus != null) toFocus.requestFocus();
    }

    private View makeTile(final AppEntry app) {
        final FrameLayout f = new FrameLayout(this);
        f.setFocusable(true);
        f.setClickable(true);
        f.setTag(app);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1B2B66);
        bg.setCornerRadius(px(12));
        f.setBackground(bg);
        f.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        f.setClipToOutline(true);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(app.image);
        if (app.isBanner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int s = px(54);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(s, s);
            ip.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
            ip.topMargin = px(12);
            f.addView(iv, ip);

            TextView label = makeText(13 * unit, Color.WHITE, false);
            label.setText(app.label);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.BOTTOM;
            lp.bottomMargin = px(9);
            lp.leftMargin = px(4);
            lp.rightMargin = px(4);
            f.addView(label, lp);
        }

        // Белая рамка при фокусе
        GradientDrawable ring = new GradientDrawable();
        ring.setColor(Color.TRANSPARENT);
        ring.setCornerRadius(px(12));
        ring.setStroke(Math.max(2, px(3)), Color.WHITE);
        StateListDrawable fg = new StateListDrawable();
        fg.addState(new int[]{android.R.attr.state_focused}, ring);
        fg.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        f.setForeground(fg);

        f.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                float s = hasFocus ? 1.07f : 1f;
                if (REDUCED_MOTION) {
                    v.setScaleX(s);
                    v.setScaleY(s);
                } else {
                    v.animate().scaleX(s).scaleY(s).setDuration(110).start();
                }
            }
        });

        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(app);
            }
        });

        // Долгое нажатие OK: «О приложении» (остановить / удалить)
        f.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + app.pkg));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    toast("Не удалось открыть настройки приложения");
                }
                return true;
            }
        });

        return f;
    }

    private void launch(AppEntry app) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setClassName(app.pkg, app.activity);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Exception e) {
            toast("Не удалось запустить " + app.label);
        }
    }

    // ================= Источники сигнала =================

    private void showSources() {
        final TvInputManager m = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
        List<TvInputInfo> inputs = null;
        try {
            if (m != null) inputs = m.getTvInputList();
        } catch (Throwable ignored) {
        }
        if (inputs == null || inputs.isEmpty()) {
            toast("Источники не найдены");
            return;
        }

        final List<TvInputInfo> list = inputs;
        final String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            TvInputInfo info = list.get(i);
            CharSequence label = null;
            try {
                label = info.loadCustomLabel(this);
            } catch (Throwable ignored) {
            }
            if (label == null || label.length() == 0) label = info.loadLabel(this);
            String name = label == null ? info.getId() : label.toString();
            try {
                if (info.isPassthroughInput()
                        && m.getInputState(info.getId()) == TvInputManager.INPUT_STATE_CONNECTED) {
                    name += "  •  подключено";
                }
            } catch (Throwable ignored) {
            }
            names[i] = name;
        }

        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Источники")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openInput(list.get(which));
                    }
                })
                .show();
    }

    private void openInput(TvInputInfo info) {
        try {
            Uri uri;
            if (info.isPassthroughInput()) {
                uri = TvContract.buildChannelUriForPassthroughInput(info.getId());
            } else {
                uri = TvContract.Channels.CONTENT_URI;
            }
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Не удалось открыть источник");
        }
    }

    // ================= Прочее =================

    /** Ищет установленное приложение Happ (по имени пакета или названию) и запускает его. */
    private void openHapp() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> all = new ArrayList<ResolveInfo>();
        List<ResolveInfo> a = pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0);
        List<ResolveInfo> b = pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        if (a != null) all.addAll(a);
        if (b != null) all.addAll(b);

        for (ResolveInfo ri : all) {
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            CharSequence l = ri.loadLabel(pm);
            String label = l == null ? "" : l.toString().toLowerCase(Locale.ROOT);
            if (pkg.contains("happ") || label.startsWith("happ")) {
                try {
                    Intent i = new Intent(Intent.ACTION_MAIN);
                    i.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    startActivity(i);
                    return;
                } catch (Exception ignored) {
                }
            }
        }
        toast("Happ не найден. Установите приложение (долгое OK на иконке — настройки сети)");
    }

    private void openSettings(String action) {
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e2) {
                toast("Настройки недоступны");
            }
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}

#!/usr/bin/env bash
# Общие функции. Нужен adb (Android platform-tools) и TV_HOST=IP телевизора.
set -u
: "${TV_HOST:?Укажите IP телевизора: export TV_HOST=192.168.1.50}"
TV="$TV_HOST:5555"
adb connect "$TV" >/dev/null 2>&1 || true
tv() { adb -s "$TV" shell "$@"; }
tv_pkgs() { tv pm list packages 2>/dev/null | tr -d '\r' | sed 's/^package://' | sort; }

#!/usr/bin/env bash
# Отключает пакеты из tools/packages.txt (pm disable-user), без root.
# Список реально отключённых пакетов сохраняется в tools/disabled.txt для restore.sh.
cd "$(dirname "$0")" && . ./common.sh
LIST="${1:-packages.txt}"
have="$(tv_pkgs)"
touch disabled.txt
while read -r p; do
  p="${p%%#*}"; p="$(echo "$p" | xargs)"; [ -z "$p" ] && continue
  case "$p" in com.yandex.tv.home|com.android.*|com.google.*|com.mediatek*|mstar*)
    echo "ПРОПУСК (защищён): $p"; continue;; esac
  if echo "$have" | grep -qx "$p"; then
    if tv pm disable-user --user 0 "$p" | grep -q "new state"; then
      echo "отключён: $p"; echo "$p" >> disabled.txt
    else echo "не удалось: $p"; fi
  else echo "нет на ТВ: $p"; fi
done < "$LIST"
echo; echo "Отключено: $(wc -l < disabled.txt). Откат: tools/restore.sh"

#!/usr/bin/env bash
# Ставит APK и делает Light Home лаунчером по умолчанию.
# Использование: TV_HOST=192.168.1.50 tools/install.sh app-release.apk [--disable-stock]
cd "$(dirname "$0")" && . ./common.sh
APK="${1:?Укажите путь к APK}"
case "$APK" in /*) ;; *) APK="$OLDPWD/$APK";; esac
STOCK=com.yandex.tv.home

adb -s "$TV" install -r "$APK" || { echo "Установка не удалась"; exit 1; }
tv pm list packages | tr -d '\r' | grep -q ru.lighthome || { echo "Лаунчер не установился"; exit 1; }

# 1) Нормальный способ: назначить домашний экран
tv cmd package set-home-activity ru.lighthome/.MainActivity 2>&1 || true
tv input keyevent KEYCODE_HOME
sleep 2
cur="$(tv cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME | tr -d '\r' | grep -m1 packageName)"
echo "Домашний экран сейчас: $cur"

if echo "$cur" | grep -q ru.lighthome; then
  echo "Готово: Light Home — лаунчер по умолчанию."
elif [ "${2:-}" = "--disable-stock" ]; then
  # 2) Запасной способ: отключить штатный лаунчер ТОЛЬКО когда наш уже установлен
  tv pm disable-user --user 0 "$STOCK" && echo "$STOCK" >> disabled.txt
  tv input keyevent KEYCODE_HOME
  echo "Штатный лаунчер отключён. Вернуть: tools/restore.sh"
else
  echo "Система не приняла назначение. Варианты: нажмите Home на пульте и выберите"
  echo "Light Home -> «Всегда», либо запустите с --disable-stock (см. README)."
fi

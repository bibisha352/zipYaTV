#!/usr/bin/env bash
# Откат: включает всё, что отключали, и возвращает штатный лаунчер Яндекса.
cd "$(dirname "$0")" && . ./common.sh
{ cat disabled.txt 2>/dev/null; echo com.yandex.tv.home; } | sort -u | while read -r p; do
  [ -z "$p" ] && continue
  tv pm enable "$p" | tr -d '\r'
done
tv cmd package set-home-activity com.yandex.tv.home 2>/dev/null || true
tv input keyevent KEYCODE_HOME
echo "Откат выполнен. Если пакеты, которые вы отключали вручную, не в disabled.txt — включите их через Настройки → Приложения."

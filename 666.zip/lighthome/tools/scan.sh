#!/usr/bin/env bash
# Показывает, что есть на ТВ: пакеты Яндекса/ivi/метрики и кто сколько ест памяти.
# Ничего не меняет. Результат — в scan.txt, из него выбирайте, что отключать.
cd "$(dirname "$0")" && . ./common.sh
{
  echo "### Android: $(tv getprop ro.build.version.release) / SDK $(tv getprop ro.build.version.sdk)"
  echo "### Лаунчер по умолчанию:"; tv cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME | tr -d '\r' | grep -m1 name=
  echo; echo "### Кандидаты (yandex|ivi|metrica|disk|ads|stat|telemetry|update):"
  tv_pkgs | grep -Ei 'yandex|ru\.ivi|metrica|disk|\.ads|stat|telemetry|ota|update' 
  echo; echo "### Топ по памяти (PSS):"
  tv dumpsys meminfo | tr -d '\r' | sed -n '/Total PSS by process/,/^$/p' | head -40
} | tee scan.txt
echo; echo "Сохранено в tools/scan.txt"

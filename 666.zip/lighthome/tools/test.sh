#!/usr/bin/env bash
# Безопасный тест на живом ТВ: ставит APK и запускает как ОБЫЧНОЕ приложение.
# Домашним экраном НЕ назначается, штатный лаунчер и сервисы не трогаются.
# Использование: TV_HOST=192.168.1.50 tools/test.sh app-release.apk
cd "$(dirname "$0")" && . ./common.sh
APK="${1:?Укажите путь к APK}"
case "$APK" in /*) ;; *) APK="$OLDPWD/$APK";; esac

adb -s "$TV" install -r "$APK" || exit 1
tv am force-stop ru.lighthome
tv am start -n ru.lighthome/.MainActivity >/dev/null
sleep 4

adb -s "$TV" exec-out screencap -p > screenshot.png && echo "Скриншот: tools/screenshot.png"
echo; echo "== Память лаунчера (строка TOTAL PSS, КБ; цель < 30000) =="
tv dumpsys meminfo ru.lighthome | tr -d '\r' | grep -E "TOTAL|Java Heap|Graphics" | head -5
echo; echo "== Свободно в системе =="
tv dumpsys meminfo | tr -d '\r' | grep -E "Free RAM|Used RAM"
echo; echo "== Ошибки лаунчера в логе =="
tv logcat -d -s AndroidRuntime:E 2>/dev/null | tr -d '\r' | tail -15
echo; echo "Проверьте пультом: стрелки, OK, Источники, иконка Wi-Fi (Happ), долгое OK."
echo "Выход: кнопка Home вернёт штатный лаунчер. Удалить: adb -s $TV uninstall ru.lighthome"
